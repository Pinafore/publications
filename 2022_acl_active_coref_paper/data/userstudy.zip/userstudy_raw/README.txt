This folder contains the raw data from the user study for the ACL 2022 publication: "Adapting Coreference Resolution Models through Active Learning".

Our user study consists of two sessions: 1) FewDocs, 2) ManyDocs. The FewDocs data is located in session1_raw.csv and the ManyDocs data is located in session2_raw.csv. Please see paper for information about the two sessions.

The data was collected with approval from the Institutional Review Board. We have made sure to anonymize any information about the participants.
